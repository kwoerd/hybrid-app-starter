import{az as t}from"./index-z4coM1MI.js";function n(o){return t(...o)}export{n as concatHex};
