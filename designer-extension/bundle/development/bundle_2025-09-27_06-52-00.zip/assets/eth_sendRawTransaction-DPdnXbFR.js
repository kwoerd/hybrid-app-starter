async function t(a,n){return await a({method:"eth_sendRawTransaction",params:[n]})}export{t as e};
