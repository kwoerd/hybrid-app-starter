import{M as s}from"./index-z4coM1MI.js";async function m(t,e){const a=await t({method:"eth_estimateGas",params:[e]});return s(a)}export{m as eth_estimateGas};
